function [miu,phi0]=Learning_Rate(theta,dJdtheta,c,x,t,difference)

global miu0 miu1 miumax c1 c2 delta

miul=miu0; % The initialization of the step length at the last time step.
miu=miu1; % The initialization of the step length at the current time step.
mium=miumax; % The adaptive maximum miu.
i=1; % The index of counting the times of iteration.

[phi0,dphi0]=phi(0.0,theta,dJdtheta,c,x,t,difference);
while dphi0>0.0
    delta=delta/2;
    [phi0,dphi0]=phi(0.0,theta,dJdtheta,c,x,t,difference);
end
% The assignment of the initialization of 'phi0' and 'dphi0'.
% 'phi' is a function with variant outputs and inputs. 'dphoi0' is the varargout variable and 'difference' is the varargin variable in this case. The varargout is the derivative of the univariate function, and 'difference' is used for the computation of 'phi0' and 'dphi0' only. 

phimiul=phi0; % The assignment of the last phi of miu.

while 1
    [phimiu,dphimiu]=phi(miu,theta,dJdtheta,c,x,t);
    % 'phi' is a function with variable outputs. The first output is the residual function for a step length, and the second output is the derivative of the residual function with respect to the step length. The second output is omittable. 
    if phimiu>phi0+c1*miu*dphi0 || (i>1 && phimiu>=phimiul+1.0e-6)
        miu=zoom(miul,miu,theta,dJdtheta,c,x,t,phi0,dphi0);
        break;
    end        
    if abs(dphimiu)<=-c2*dphi0
        break;
    end
    if dphimiu>=0
        miu=zoom(miu,miul,theta,dJdtheta,c,x,t,phi0,dphi0); 
        break;
    end
    miul=miu;
    phimiul=phimiu;
    miu=(miu+mium)/2.0;
    if abs(miu-mium)<=1.0e-7
        mium=2.0*mium;
    end
    i=i+1;
end

end


function miu=zoom(low,high,theta,dJdtheta,c,x,t,phi0,dphi0)

global c1 c2 delta

miu=(low+high)/2.0;
[phimiu,dphimiu]=phi(miu,theta,dJdtheta,c,x,t);
[philow,dphilow]=phi(low,theta,dJdtheta,c,x,t);

while 1
   % The function 'phi' is like the same one as used in the function of 'zoom'.
   if phimiu>phi0+c1*miu*dphi0 || phimiu>=philow+1.0e-6
       high=miu;
   else
       if abs(dphimiu)<=-c2*dphi0
           break;
       end
       if dphimiu*(high-low-1.0e-6)>=0.0
           high=low; 
       end
       low=miu;
       philow=phimiu;
       if abs(high-low)<1.0e-6
           high=high/2.0;
           low=low/2.0;
           [philow,dphilow]=phi(low,theta,dJdtheta,c,x,t); 
       end
   end
   if abs(low-high)<delta
       miu=(low+high)/2.0;
       break
   end
   miu=(low+high)/2.0;
   [phimiu,dphimiu]=phi(miu,theta,dJdtheta,c,x,t);
end
 
end


function [fai1,varargout]=phi(miu,theta,dJdtheta,c,x,t,varargin)

global K L N M tao delta

Q=K+L*(N-M); % The number of all composite parameters.

fai1=0.0; % The initialization of the univariate function estimated at the estimated step length 'miu'.
fai2=0.0; % The initialization of the univariate function estimated at the incremented estimated step length 'miu+delta'.

if nargin==6
    theta1=theta-miu*dJdtheta; % The predicted parameters.
    p=theta1(1:K); % The extraction of the ODE parameters.
    c(:,M+1)=theta1(K+1:Q); % The extraction of the initial conditions of hidden variables.
    % 'theta1' is the parameter vector estimated at miu in the univariate function.
   
    for l=1:L
        [tys{l},ys{l}]=Original_ODE_Solver(p,c(l,:),tao(l),tao(l+1));
    end % Computation of the estimated solution with the new parameters 'newtheta'.
    y=Interpolation(tys,ys,t); % The interpolation of the new estimated solutions. 

    for i=1:M
        fai1=fai1+sum((y(:,i)-x(:,i)).^2);
    end % The computation of the univariate function estimated at 'miu'.
else
    for i=1:M
        fai1=fai1+sum(varargin{1}.^2);
    end
end

if nargout==2
    theta2=theta-(miu+delta)*dJdtheta;
    p=theta2(1:K); % The extraction of the ODE parameters.
    c(:,M+1)=theta2(K+1:Q); % The extraction of the initial conditions of hidden variables.
    % 'theta2' is the parameter vector estimated at 'miu+delta' in the univariate function.
    for l=1:L
        [tys{l},ys{l}]=Original_ODE_Solver(p,c(l,:),tao(l),tao(l+1));
    end % Computation of the estimated solution with the new parameters 'newtheta'.
    y=Interpolation(tys,ys,t); % The interpolation of the new estimated solutions. 
   
    for i=1:M
        fai2=fai2+sum((y(:,i)-x(:,i)).^2);
    end % The computation of the univariate function estiamted at 'miu+delta'

    varargout{1}=(fai2-fai1)/delta; % The computation of the derivative of the univariate function. 
end

end






    








