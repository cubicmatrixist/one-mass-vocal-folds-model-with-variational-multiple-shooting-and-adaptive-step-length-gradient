function difference=Differencing(x,y,t)

global L M s

for i=1:L+1
    if i==1 
        for j=1:M
            difference{i}(:,j)=y(:,j)-x(:,j);
        end
    else
        for j=1:M
            difference{i}(:,j)=y(s(i-1):s(i)-1,j)-x(s(i-1):s(i)-1,j);
        end
    end
end % The initialization of 'tdJdtheta' and 'difference'
% 'difference' is and 1+L* cell array for the difference between the estimated solution and the observed data. The first cell is the difference for the ODE parameters and the rest L cell arrays are the difference for the estimated segmental initial conditions of hidden variables. 

end
 