tic 

clear all

global N K L tmax T s tao nmax M miu0 miu1 miumax c1 c2 delta

N=2; % The number of variables 
K=4; % The number of parameters
L=4; % The number of the segments
M=1; % The number of the explicit components of the variable
nmax=30; % The times of iteration
Q=K+L*(N-M); % The number of components in the composite parameter.

miu0=0.0; % The initial set of the step length.
miu1=0.05; % The initial guess of the step length.
miumax=0.1; % The max step length. 
c1=1.0e-4; % The coefficient used for the sufficient decrease condition.
c2=0.9; % The coefficient used for the curvature decrease condition. 
delta=1.0e-9; % The increment used for the computation of the derivative of the univariate function.

tmax=20.0; % The time span of the observed data
p0=[1.0, 1, 10.0, 1.0]'; % The initial set of parameters, m0=1.0, b0=1.0, k0=1.0; alpha0=1.0, with the ODE md^2x/dt^2+bdx/dt+kx=alpha
c0=[0.0, 1.0]'; % The initial condition of the equation. The sequence of the initial condition vector components is the same sequence of the components of the variable.
[t,x]=Original_ODE_Solver(p0,c0); % The observed data

T=size(t,1); % The number of data in the solution
for l=1:1+L
    if l<L+1
        tao(l)=t((l-1)*(T-mod(T,L))/L+1); 
        c(l,1)=x((l-1)*(T-mod(T,L))/L+1,1); % The L array containing the explicit conditions of the hidden variables for each segment.
        c(l,2)=0.0; % The L array containing the initial conditions of the hidden variables for each segment.
        s(l)=(l-1)*(T-mod(T,L))/L+1;
    else 
        tao(l)=tmax; % The (L+1) array containing the starting time for each segment and tmax
        s(l)=T+1; % The (L+1) array containing the index of the starting point of each segment and a pseudo index T+1 for the convenience of coding.
    end 
end % The assignment of the time, the states variables, and the index of the starting points of all segments.

for i=1:1+L
    if i==1
        tdJdtheta{i}=t;
    else  
        tdJdtheta{i}=t(s(i-1):s(i)-1);
    end
end % The initialization of the time series for different parameters.
% 'tdJdtheta' is an 1+L* cell array for time series of the gradient of the residual with respect to the composite parameter based on the time series of the observed data. The first cell is the time series of the component for the ODE parameters and the rest L cell arrays are the time series of the components for the estiamted segmental initial conditions of hidden variables.

p=[1.0,1,1,1]'; % The guess of parameters, and the sequence of the components in the parameters vector is m, b, k, alpha

criterion=0.01; % Error criterion
n=0; % The index for loop

figure (1)
plot(t,x(:,1));
hold on
plot(t,x(:,2));
hold on

theta=p; % The initialization of the composite parameters vector
for l=1:L
  theta=[theta' c(l,2)']'; % The concatenation of the composite parameters vector 
end

el=0.0; % The error of the last time step.

for n=1:nmax %while e>criterion
    for l=1:L
        [tys{l},ys{l}]=Original_ODE_Solver(p,c(l,:),tao(l),tao(l+1)); % Solve the estimated solution for each segment. 
    end 
    % 'tys' is a cell array of L, and the cell l contains the time series of the segment l.
    % 'ys' is a cell array of L, and the cell l contains the estimated solution of the segment l.
    y=Interpolation(tys,ys,t); % The interpolation of the estimated solutions of all segments into the time series of the observed data.      
    difference=Differencing(x,y,t); % The residual function, the difference between the estimated solution.
    dJdtheta=Gradient_Descent(t,x,y,theta,difference,tdJdtheta); % The computation of the gradient.
    [miu,J]=Learning_Rate(theta,dJdtheta,c,x,t,difference{1}); % The computation of the step length. 'J' is an extra quantity, which is the residual function of the current estimated parameters.
    miu
    theta=theta-miu*dJdtheta;
    p=theta(1:K);
    c(:,2)=theta(K+1:Q); % The updating of all the parameters.   
    e(n)=J/T;
    "The iterated times", n
    "The updated parameters", p
    "The updated initial conditions of the hidden variable for all segments", c(:,2)
    "The difference between the estimated composite parameter in the last step and the current step", e(n)
    if abs(e(n)-el)<1.0e-16
        break
    end
    el=e(n);
end

plot(t,y(:,1));
hold on
plot(t,y(:,2));
hold on


n=1:nmax;
E(:,1)=n;
E(:,2)=e;

xlswrite('adaptive step length residual function.xls',E);

%p
%p0

toc
  
  





