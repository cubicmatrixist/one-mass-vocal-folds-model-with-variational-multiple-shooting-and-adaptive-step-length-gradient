function [tdydtheta,dydtheta]=Sensitivity_ODE_Solver(t,y,theta)
  
global tmax K N M L tao
 
for i=1:1+L
    if i==1
        ic{i}=zeros(N*K,1); % The initial conditions for the sensitivity equation for the ODE parameters
        tspan{i}=[0,tmax]'; % The time span for the sensitivity equation for the ODE parameters
    else
        for j=1:N*(N-M)
            if j<=M*(N-M) 
                ic{i}(j,1)=0.0;
            else
                ic{i}(j,1)=1.0;
            end
        end % The initial conditions for the sensitivity equation for the estimated segmental initial conditions of hidden variables.
        tspan{i}=[tao(i-1),tao(i)]; % The time span for the sensitivity equation for the estimated segmental initial conditions.
    end 
end
% 'ic' a cell array of (L+1), containing the initial conditions for the sensitivity equations for both the ODE parameters and the estimated segmental initial conditions.
% 'tspan' is an array of (L+1), containing the time spans for all the sensitivity equations. 

for i=1:1+L
    [tdydthetat,dydthetat]=ode45(@(tdydthetat,dydthetat)Sensitivity_ODE(tdydthetat,dydthetat,t,y,theta,i),tspan{i},ic{i}); 
    tdydtheta{i}=tdydthetat;
    dydtheta{i}=dydthetat;
end % The computation of the sensitivites.
% 'tdydthetat' and 'dydthetat' are the temporary arrays for 'tdydtheta' and 'dydtheta'.
% 'tdydtheta' is an 1+L*(N-M) cell array for the times series of sensitivities. The first cell is the time series of the sensitivities on the ODE parameters, and the rest L*(N-M) cells are the time series for the sensitivities of the segmental estimated initial conditions of the hidden variables.
% 'dydtheta' is a 1+L*(N-M) cell array for the sensitivities. The first cell is the sensitivities on the ODE parameters, and the rest L*(N-M) cells are the sensitivities on the estimated segmental initial conditions of hidden variables.
                          
end 