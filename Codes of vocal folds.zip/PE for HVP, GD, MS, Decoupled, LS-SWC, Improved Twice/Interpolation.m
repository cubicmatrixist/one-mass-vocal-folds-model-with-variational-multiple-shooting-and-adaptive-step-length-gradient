function y=Interpolation(tys,ys,t)

global N L s

for i=1:L % The loop for all segments.
    for j=1:N % The loop for all components 
        y(s(i):s(i+1)-1,j)=interp1(tys{i},ys{i}(:,j),t(s(i):s(i+1)-1)); %The interpolation in each segment.
    end
end 

end
      




