function dJdtheta=Gradient_Descent(t,x,y,theta,difference,tdJdtheta)

global K L M N T miu s tao

Q=K+L*(N-M); % The number of the elements of the composite parameters.

[tdydtheta0,dydtheta0]=Sensitivity_ODE_Solver(t,y,theta); % Solve the sensitivities on the ODE parameters and the estimated initial conditions. 
% 'tdydtheta0' is an 1+L*(N-M) cell array for the times series of sensitivities. The first cell is the time series of the sensitivities on the ODE parameters, and the rest L*(N-M) cells are the time series for the sensitivities of the segmental estimated initial conditions of the hidden variables.
% 'dydtheta0' is a 1+L*(N-M) cell array for the sensitivities. The first cell is the sensitivities on the ODE parameters, and the rest L*(N-M) cells are the sensitivities on the estimated segmental initial conditions of hidden variables.

for i=1:L+1
    dydtheta{i}=interp1(tdydtheta0{i},dydtheta0{i},tdJdtheta{i}); 
end  % The interpolation of the sensitivities into the time series of the observed data. This cell is only used for the storage of the sensitivities of the explicit variables. 
% 'dydtheta' is the interpolated dydtheta on the corresponding tdJdtheta. It's a cell array of 1+L*(N-M). 'dydthetait' is the temporary array for the convenience of computation. Notice that only the interpolation of the sensitivities of the explicit 

for i=1:L+1
    if i==1
        prod{i}=zeros(T,K);
    else 
        prod{i}=zeros(s(i)-s(i-1),N-M);
    end
end % The initialization of the product of the difference between the estimated solutions and the observed data for M explicit variables.
% 'prod' is a cell array of 1+L. The first cell is for the ODE parameters, and the rest L*(N-M) cells are for the estimated segmental initial conditions of the hidden variables. 

for i=1:L+1
    if i==1
        for j=1:K
            for k=1:M
                prod{i}(:,j)=prod{i}(:,j)+difference{i}(:,k).*dydtheta{i}(:,j+(k-1)*K);
            end
        end
    else
        for j=1:(N-M)
            for k=1:M
                prod{i}(:,j)=prod{i}(:,j)+difference{i}(:,k).*dydtheta{i}(:,j+(k-1)*(N-M));
            end 
        end
    end
end % The computation of the product of the difference between the estimated solutions and the observed data for the explicit variables. 

for i=1:L+1
    if (i==1)
        for j=1:K
            dJdtheta(j)=2.0*sum(prod{i}(:,j));
        end
    else
        for j=1:(N-M)
            dJdtheta(K+(i-2)*(N-M)+j)=2.0*sum(prod{i}(:,j));
        end
    end
end % The computation of the components of the gradient of the cost function with respect to the composite parameters.
% 'dJdtheta' is an array of K+L*(N-M). The first K elements are the components of the gradient of the cost function with respect to the ODE parameters and the rest L*(N-M) elements are the components of the gradient of the cost function with respect to the estimated segmental initial conditions of hidden variables. 

dJdtheta=dJdtheta';
 
end


















