function ddydthetadt=Sensitivity_ODE(tdydtheta,dydtheta,t,y,theta,i)

global K L N M

yi=interp1(t,y,tdydtheta); % The interpolation of the estimated solution onto the time series of the sensitivity equation. 

aux=[(-theta(4)+theta(2)*yi(:,2)+theta(3)*yi(:,1))/theta(1), -yi(:,2)/theta(1), -yi(:,1)/theta(1), 1.0]'; % The auxiliary array for the sensitivity equation

ddydthetadt=zeros(size(dydtheta)); % This is a necessary definition for 'ddydthetadt' so that it matches 'theta'.

if i==1 
    for j=1:N*K
        if j<=K
            ddydthetadt(j)=dydtheta(j+K);
        else 
            ddydthetadt(j)=(aux(j-K)-theta(3)*dydtheta(j-K)-theta(2)*dydtheta(j))/theta(1);
        end
    end
else 
    for j=1:N*(N-M)
        if j<=(N-M)
            ddydthetadt(j)=dydtheta(j+(N-M));
        else
            ddydthetadt(j)=-(theta(3)*dydtheta(j-(N-M))+theta(2)*dydtheta(j))/theta(1);
        end 
    end
end    

end