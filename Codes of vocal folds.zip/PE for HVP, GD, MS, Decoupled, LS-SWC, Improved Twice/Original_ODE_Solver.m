function [t,x]=Original_ODE_Solver(p,c,varargin)

global tmax

if nargin==2
    tspan=[0,tmax];
    [t,x]=ode45(@(t,x)Original_ODE(p,x),tspan,c);
else
    tspan=[varargin{1,1},varargin{1,2}]; % varargin is the variable-length input argument list, which is a 1*N cell array, where N is the additional input arguments. 
    [t,x]=ode45(@(t,x)Original_ODE(p,x),tspan,c);
end

end
