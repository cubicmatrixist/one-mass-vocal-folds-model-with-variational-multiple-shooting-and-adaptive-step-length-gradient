function dxdt=Original_ODE(p,x)

  dxdt=zeros(size(x));
  dxdt(1)=x(2);
  dxdt(2)=(p(4)-p(2)*x(2)-p(3)*x(1))/p(1);

end